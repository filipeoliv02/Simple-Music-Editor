var searchData=
[
  ['seg',['seg',['../structlrc.html#a1d5f6f91d20f3974c9d03f6bb56afc27',1,'lrc']]]
];
