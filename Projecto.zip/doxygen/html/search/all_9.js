var searchData=
[
  ['tam_5fnome',['TAM_NOME',['../project_8h.html#ad0e480e07eae04b077948c75deb75422',1,'project.h']]],
  ['tam_5fvector',['TAM_VECTOR',['../project_8h.html#ae09ba62ef655bddf3ff4678f8d3a7d26',1,'project.h']]],
  ['temp_2ec',['temp.c',['../temp_8c.html',1,'']]],
  ['texto',['texto',['../structlrc.html#a0483fa55a1e6e8682a762fdb280d18d2',1,'lrc']]],
  ['titulo',['titulo',['../structmusica.html#a6dba2e20e00fd8307192a7e0dce4b3d9',1,'musica']]]
];
