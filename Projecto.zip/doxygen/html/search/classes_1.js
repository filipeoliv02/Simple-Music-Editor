var searchData=
[
  ['lrc',['lrc',['../structlrc.html',1,'']]]
];
