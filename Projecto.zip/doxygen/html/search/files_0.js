var searchData=
[
  ['main_2ec',['main.c',['../main_8c.html',1,'']]],
  ['menu_5falbum_2ec',['menu_album.c',['../menu__album_8c.html',1,'']]],
  ['menu_5fartist_2ec',['menu_artist.c',['../menu__artist_8c.html',1,'']]],
  ['menu_5fedit_5fremove_2ec',['menu_edit_remove.c',['../menu__edit__remove_8c.html',1,'']]],
  ['menu_5fmusic_2ec',['menu_music.c',['../menu__music_8c.html',1,'']]],
  ['menu_5fpr_2ec',['menu_pr.c',['../menu__pr_8c.html',1,'']]],
  ['menu_5fsearch_2ec',['menu_search.c',['../menu__search_8c.html',1,'']]],
  ['menu_5fyear_2ec',['menu_year.c',['../menu__year_8c.html',1,'']]]
];
