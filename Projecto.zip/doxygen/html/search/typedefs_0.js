var searchData=
[
  ['artista',['ARTISTA',['../project_8h.html#a8f88f8ad560381cf6e92b1ff3ca5efb2',1,'project.h']]]
];
