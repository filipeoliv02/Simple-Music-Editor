var searchData=
[
  ['album_5fsearch',['album_search',['../menu__album_8c.html#a8e05ef4493750f4348b12f44571a0cb4',1,'album_search():&#160;menu_album.c'],['../project_8h.html#a8e05ef4493750f4348b12f44571a0cb4',1,'album_search():&#160;menu_album.c']]],
  ['artist_5fadd',['artist_add',['../menu__artist_8c.html#aa0cc094bdfe1f29db5fe4c4405b2ddde',1,'artist_add(struct artista *a):&#160;menu_artist.c'],['../project_8h.html#aa0cc094bdfe1f29db5fe4c4405b2ddde',1,'artist_add(struct artista *a):&#160;menu_artist.c']]],
  ['artist_5fedit',['artist_edit',['../menu__artist_8c.html#ab41a14f04e6032035587c9c22e60271a',1,'artist_edit(struct artista *a):&#160;menu_artist.c'],['../project_8h.html#ab41a14f04e6032035587c9c22e60271a',1,'artist_edit(struct artista *a):&#160;menu_artist.c']]],
  ['artist_5finput',['artist_input',['../menu__artist_8c.html#a30a0e556624bca6a1523351a151cf84c',1,'artist_input(char *temp):&#160;menu_artist.c'],['../project_8h.html#a30a0e556624bca6a1523351a151cf84c',1,'artist_input(char *temp):&#160;menu_artist.c']]],
  ['artist_5flist',['artist_list',['../menu__artist_8c.html#a8f711ef177fff9555d0d9b7dbd02fe0e',1,'artist_list():&#160;menu_artist.c'],['../project_8h.html#a8f711ef177fff9555d0d9b7dbd02fe0e',1,'artist_list():&#160;menu_artist.c']]],
  ['artist_5fload',['artist_load',['../menu__artist_8c.html#ac92e93ea1e283f63cd157c3de3bda0d2',1,'artist_load():&#160;menu_artist.c'],['../project_8h.html#ac92e93ea1e283f63cd157c3de3bda0d2',1,'artist_load():&#160;menu_artist.c']]],
  ['artist_5fprint',['artist_print',['../menu__artist_8c.html#a0b753a63f0f576d94160e7d073332c66',1,'artist_print(struct artista *a):&#160;menu_artist.c'],['../project_8h.html#a0b753a63f0f576d94160e7d073332c66',1,'artist_print(struct artista *a):&#160;menu_artist.c']]],
  ['artist_5fremove',['artist_remove',['../menu__artist_8c.html#abc42f3a57f943f92d23752d9650031f9',1,'artist_remove(struct artista *a):&#160;menu_artist.c'],['../project_8h.html#abc42f3a57f943f92d23752d9650031f9',1,'artist_remove(struct artista *a):&#160;menu_artist.c']]],
  ['artist_5fsave',['artist_save',['../menu__artist_8c.html#a8defa4fde9758146417715dd117615d2',1,'artist_save():&#160;menu_artist.c'],['../project_8h.html#a8defa4fde9758146417715dd117615d2',1,'artist_save():&#160;menu_artist.c']]],
  ['artist_5fsearch',['artist_search',['../menu__artist_8c.html#ac92bcae8044b83bc1a51fa19509f1979',1,'artist_search():&#160;menu_artist.c'],['../project_8h.html#ac92bcae8044b83bc1a51fa19509f1979',1,'artist_search():&#160;menu_artist.c']]]
];
