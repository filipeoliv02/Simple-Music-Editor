var searchData=
[
  ['texto',['texto',['../structlrc.html#a0483fa55a1e6e8682a762fdb280d18d2',1,'lrc']]],
  ['titulo',['titulo',['../structmusica.html#a6dba2e20e00fd8307192a7e0dce4b3d9',1,'musica']]]
];
