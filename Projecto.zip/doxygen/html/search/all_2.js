var searchData=
[
  ['gravar_5fficheiro',['gravar_ficheiro',['../project_8h.html#a66e40e3c4fe80bd64ffc8f71b2222486',1,'project.h']]]
];
