var searchData=
[
  ['nacionalidade',['nacionalidade',['../structartista.html#a1ea0358b1dadca215efb6586f6714271',1,'artista']]],
  ['nome',['nome',['../structartista.html#a69b32c1c4f965a4119eabc9f94886621',1,'artista']]],
  ['num_5fletras',['num_letras',['../structmusica.html#a65092ca80b96aad412ee3f06c9b506e3',1,'musica']]]
];
