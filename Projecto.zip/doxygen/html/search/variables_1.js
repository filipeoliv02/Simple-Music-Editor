var searchData=
[
  ['cantor',['cantor',['../structmusica.html#a8b6fc763fbedbcbdf1ed51a276b15e9b',1,'musica']]],
  ['cs',['cs',['../structlrc.html#ad35c7ed2784f4fb57849237ce534f17e',1,'lrc']]]
];
