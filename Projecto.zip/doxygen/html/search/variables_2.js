var searchData=
[
  ['letras',['letras',['../structmusica.html#a5243e7f8641c5be23da1e7391c8fc4d6',1,'musica']]],
  ['lrc_5ffile',['lrc_file',['../temp_8c.html#a6bdee275ef83c0d0cda5fef9f676def6',1,'temp.c']]]
];
