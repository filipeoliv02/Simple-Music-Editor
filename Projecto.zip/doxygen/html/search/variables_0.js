var searchData=
[
  ['album',['album',['../structmusica.html#a5e90504f1995d65d2fe8574737998255',1,'musica']]],
  ['ano',['ano',['../structmusica.html#a425a18cdc020d8ccc82c46c220d521f9',1,'musica']]],
  ['artist_5ffile',['artist_file',['../menu__artist_8c.html#ae03497d4c5787584c1e6cf070ecf983a',1,'menu_artist.c']]],
  ['artist_5fnum',['artist_num',['../menu__artist_8c.html#a8d82d06e41678bc11a48e87a03a015c4',1,'artist_num():&#160;menu_artist.c'],['../project_8h.html#a8d82d06e41678bc11a48e87a03a015c4',1,'artist_num():&#160;project.h']]],
  ['artista',['artista',['../structmusica.html#a3ece80975d3e1263d85091ba633e7690',1,'musica']]]
];
