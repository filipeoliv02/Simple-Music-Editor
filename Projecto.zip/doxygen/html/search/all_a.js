var searchData=
[
  ['vec_5fartistas',['vec_artistas',['../project_8h.html#ad7366ec3b30d40056803ba82b07bedbb',1,'project.h']]],
  ['vec_5fmusicas',['vec_musicas',['../project_8h.html#aecc89fa6b382a59cfae03f0d18156808',1,'project.h']]]
];
