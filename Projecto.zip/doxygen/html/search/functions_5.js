var searchData=
[
  ['main',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['menu_5fartist',['menu_artist',['../menu__artist_8c.html#a7c5e73158caf3dee7454843b4bb18325',1,'menu_artist():&#160;menu_artist.c'],['../project_8h.html#a7c5e73158caf3dee7454843b4bb18325',1,'menu_artist():&#160;menu_artist.c']]],
  ['menu_5fartist_5fedit',['menu_artist_edit',['../project_8h.html#a401bf9677fc64397b3fa33567e884aa7',1,'project.h']]],
  ['menu_5fedit',['menu_edit',['../project_8h.html#af746c1e5283b3e90dd4c74bc2626ed03',1,'project.h']]],
  ['menu_5fedit_5fremove_5fartist',['menu_edit_remove_artist',['../menu__edit__remove_8c.html#ade4b36ae37d77141b3131c7758bed507',1,'menu_edit_remove_artist(struct artista *a):&#160;menu_edit_remove.c'],['../project_8h.html#ade4b36ae37d77141b3131c7758bed507',1,'menu_edit_remove_artist(struct artista *a):&#160;menu_edit_remove.c']]],
  ['menu_5fedit_5fremove_5fmusic',['menu_edit_remove_music',['../menu__edit__remove_8c.html#a09eb36429e9653f2df30b4127c1158ab',1,'menu_edit_remove_music(struct musica *m):&#160;menu_edit_remove.c'],['../project_8h.html#a09eb36429e9653f2df30b4127c1158ab',1,'menu_edit_remove_music(struct musica *m):&#160;menu_edit_remove.c']]],
  ['menu_5fmusic',['menu_music',['../menu__music_8c.html#a088df08a705b7c74bda39434bbefa5c8',1,'menu_music():&#160;menu_music.c'],['../project_8h.html#a088df08a705b7c74bda39434bbefa5c8',1,'menu_music():&#160;menu_music.c']]],
  ['menu_5fpr',['menu_pr',['../menu__pr_8c.html#a5b211bda275b9a60f9dac70877e9622e',1,'menu_pr():&#160;menu_pr.c'],['../project_8h.html#a5b211bda275b9a60f9dac70877e9622e',1,'menu_pr():&#160;menu_pr.c']]],
  ['menu_5fsearch',['menu_search',['../menu__search_8c.html#a0fa77fad4bd4f6d18677cc1ab442172b',1,'menu_search():&#160;menu_search.c'],['../project_8h.html#a0fa77fad4bd4f6d18677cc1ab442172b',1,'menu_search():&#160;menu_search.c']]],
  ['music_5fadd',['music_add',['../menu__music_8c.html#a0601269df7d88d6fe6b66fbbbdc589cb',1,'music_add(struct musica *m):&#160;menu_music.c'],['../project_8h.html#a0601269df7d88d6fe6b66fbbbdc589cb',1,'music_add(struct musica *m):&#160;menu_music.c']]],
  ['music_5fedit',['music_edit',['../menu__music_8c.html#a86e0526889a472c55b6599489e04e164',1,'music_edit(struct musica *m):&#160;menu_music.c'],['../project_8h.html#a86e0526889a472c55b6599489e04e164',1,'music_edit(struct musica *m):&#160;menu_music.c']]],
  ['music_5finput',['music_input',['../menu__music_8c.html#a3cde506a190f5edc6ccd1a9f92f00afc',1,'music_input(char *temp):&#160;menu_music.c'],['../project_8h.html#a3cde506a190f5edc6ccd1a9f92f00afc',1,'music_input(char *temp):&#160;menu_music.c']]],
  ['music_5flist',['music_list',['../menu__music_8c.html#a805fc5a774bc1872a74344155c721bd4',1,'music_list():&#160;menu_music.c'],['../project_8h.html#a805fc5a774bc1872a74344155c721bd4',1,'music_list():&#160;menu_music.c']]],
  ['music_5fload',['music_load',['../menu__music_8c.html#a35fb249f740a3763e67875658fb507ec',1,'music_load():&#160;menu_music.c'],['../project_8h.html#a35fb249f740a3763e67875658fb507ec',1,'music_load():&#160;menu_music.c']]],
  ['music_5fprint',['music_print',['../menu__music_8c.html#a0593b129f68797b24a9ddbec810a80e9',1,'music_print(struct musica *m):&#160;menu_music.c'],['../project_8h.html#a0593b129f68797b24a9ddbec810a80e9',1,'music_print(struct musica *m):&#160;menu_music.c']]],
  ['music_5fremove',['music_remove',['../menu__music_8c.html#a3ed1d066f06b3b8ce2416cf4418231f9',1,'music_remove(struct musica *m):&#160;menu_music.c'],['../project_8h.html#a3ed1d066f06b3b8ce2416cf4418231f9',1,'music_remove(struct musica *m):&#160;menu_music.c']]],
  ['music_5fsave',['music_save',['../menu__music_8c.html#aca4dc8bca342d560906d9c5a375e5b52',1,'music_save():&#160;menu_music.c'],['../project_8h.html#aca4dc8bca342d560906d9c5a375e5b52',1,'music_save():&#160;menu_music.c']]],
  ['music_5fsearch',['music_search',['../menu__music_8c.html#acd2ed77d07ab0a38a48ff3e12e405a37',1,'music_search():&#160;menu_music.c'],['../project_8h.html#acd2ed77d07ab0a38a48ff3e12e405a37',1,'music_search():&#160;menu_music.c']]]
];
