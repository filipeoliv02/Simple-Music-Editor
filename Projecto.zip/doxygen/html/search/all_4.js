var searchData=
[
  ['letras',['letras',['../structmusica.html#a5243e7f8641c5be23da1e7391c8fc4d6',1,'musica']]],
  ['lista_5ftodas_5fmusicas',['lista_todas_musicas',['../menu__pr_8c.html#a44ba4b9e88b997f3011edeb8b9742eca',1,'lista_todas_musicas():&#160;menu_pr.c'],['../project_8h.html#a44ba4b9e88b997f3011edeb8b9742eca',1,'lista_todas_musicas():&#160;menu_pr.c']]],
  ['lrc',['lrc',['../structlrc.html',1,'']]],
  ['lrc_5ffile',['lrc_file',['../temp_8c.html#a6bdee275ef83c0d0cda5fef9f676def6',1,'temp.c']]],
  ['lrc_5fload',['lrc_load',['../project_8h.html#a0c43d8e1a93bdb19f97c4d8d1b214643',1,'lrc_load(struct musica *m):&#160;temp.c'],['../temp_8c.html#a0c43d8e1a93bdb19f97c4d8d1b214643',1,'lrc_load(struct musica *m):&#160;temp.c']]],
  ['lrc_5fprint',['lrc_print',['../menu__edit__remove_8c.html#a6532a6f938a3cc8b70d7c43fafc1422e',1,'lrc_print(struct musica *m):&#160;menu_edit_remove.c'],['../project_8h.html#a9af19c526d7c84879267f09afde85e57',1,'lrc_print():&#160;project.h']]]
];
