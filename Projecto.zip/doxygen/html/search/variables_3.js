var searchData=
[
  ['min',['min',['../structlrc.html#a3e202b201e6255d975cd6d3aff1f5a4d',1,'lrc']]],
  ['music_5ffile',['music_file',['../menu__music_8c.html#a60b482a81a97025e2040341d609a3d88',1,'menu_music.c']]],
  ['music_5fnum',['music_num',['../menu__music_8c.html#a2fc88755839757d7176cb71c37064b39',1,'music_num():&#160;menu_music.c'],['../project_8h.html#a2fc88755839757d7176cb71c37064b39',1,'music_num():&#160;project.h']]]
];
