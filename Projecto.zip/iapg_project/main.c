#include "project.h"
int main() {
    menu_pr();      ///abre o menu principal
    return 0;
}